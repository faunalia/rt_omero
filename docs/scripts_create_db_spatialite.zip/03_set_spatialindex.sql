VACUUM;

SELECT CreateSpatialIndex('geometrie_unita_volumetriche_originali_di_partenza','geometria');
SELECT CreateSpatialIndex('ZZ_COMUNI','geometria');


